package Profile;


// Main Class or Parent Class 
public class weakness {
	String proc = "•Procrastination";
	String pub = "•Public Speaking";
	String self = "•Self-Criticism";
	String lack = "•Lacking Confidence";
	String slow = "•Slow Learner";

}
