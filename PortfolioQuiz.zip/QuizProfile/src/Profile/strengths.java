package Profile;

public class strengths extends weakness {
	String crea = "•Creative";
	String time = "•Time Management";
	String typing = "•Typing Skills";
	String dedication = "•Dedication";
	String multi = "•Multitasking";

}
