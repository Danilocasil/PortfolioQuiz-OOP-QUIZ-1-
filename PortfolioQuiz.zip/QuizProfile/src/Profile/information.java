package Profile;

public class information extends strengths {
	String name = "Casil, Danilo Jr. B.";
	String sex = "Male";
	String birthday = "December 20, 2001";
	String age = "21";
	String school = "National University";
	String course = "BSIT Specialization";
	String specialization = "Multimedia Arts and Animation";
	String hair = "Black";

}
